from flask import Flask, render_template
from flask_socketio import SocketIO
import webbrowser

app = Flask(__name__)
socketio = SocketIO(app, cors_allowed_origins="*")  # Allow connections from any origin

@app.route('/')
def index():
    return render_template('map.html')

@socketio.on('update_map')
def handle_update(data):
    print(f"Received data from Python script: {data}")
    socketio.emit('update_map', data)  # Broadcast the data to all connected clients

def open_browser():
    # Open the default web browser to the Flask app
    webbrowser.open('http://127.0.0.1:5000')

if __name__ == '__main__':
    # Schedule the open_browser function to run after the server starts
    socketio.start_background_task(open_browser)
    
    # Run the Flask app with SocketIO
    socketio.run(app, debug=True, use_reloader=False)
