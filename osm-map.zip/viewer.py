import tkinter as tk
from tkinter import ttk
import os
import webview
import logging

class OSMMapApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Interactive OpenStreetMap with Tkinter")

        self.map_frame = ttk.Frame(self.root)
        self.map_frame.pack(expand=True, fill="both")

        self.create_map()

    def create_map(self):
        # Configure logging to redirect output to a file
        #logging.basicConfig(filename='webview_debug.log', level=logging.DEBUG)

        # Use pywebview to display the HTML file in a Tkinter window
        webview.create_window(
            "OSM Map",
            url="file://" + os.path.abspath("viewer.html"),
            width=800,
            height=600,
            js_api=on_webview_ready  # Execute on_webview_ready when the WebView is ready
        )
        webview.start(debug=False)  # Enable debugging

def on_webview_ready(webview):
    # This function is called when the WebView is ready
    # Execute JavaScript code to connect to the Socket.IO server
    webview.evaluate_js('var socket = io.connect("http://127.0.0.1:5000");')

if __name__ == "__main__":
    root = tk.Tk()
    app = OSMMapApp(root)
    root.mainloop()
