// service-worker.js
const cacheName = 'my-cache';

self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(cacheName).then((cache) => {
            return cache.addAll([
                '/',
                '/static/leaflet.css',
                '/static/leaflet.js',
                '/static/dist/leaflet.js',
                '/static/socket.io.js',
                '/dist/leaflet.js',

                // Add other static assets
            ]);
        })
    );
});

self.addEventListener('fetch', (event) => {
    event.respondWith(
        caches.match(event.request).then((response) => {
            return response || fetch(event.request).then((response) => {
                // Cache only images
                if (event.request.url.match(/\.(png|jpg|jpeg|gif|svg)$/i)) {
                    return caches.open(cacheName).then((cache) => {
                        cache.put(event.request, response.clone());
                        return response;
                    });
                } else {
                    return response;
                }
            });
        })
    );
});
