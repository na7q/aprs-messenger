import socketio
import time
import math
from datetime import datetime

sio = socketio.Client()

@sio.event
def connect():
    print("Connected to server")

@sio.event
def disconnect():
    print("Disconnected from server")

def calculate_new_coordinates(lat, lon, distance, bearing):
    # Function to calculate new coordinates based on distance and bearing
    radius_earth = 6371  # Earth's radius in kilometers

    # Convert latitude and longitude to radians
    lat_rad = math.radians(lat)
    lon_rad = math.radians(lon)

    # Calculate new latitude
    new_lat_rad = lat_rad + (distance / radius_earth) * math.cos(math.radians(bearing))

    # Calculate new longitude
    new_lon_rad = lon_rad + (distance / radius_earth) * math.sin(math.radians(bearing)) / math.cos(new_lat_rad)

    # Convert back to degrees
    new_lat = math.degrees(new_lat_rad)
    new_lon = math.degrees(new_lon_rad)

    return new_lat, new_lon

if __name__ == "__main__":
    sio.connect('http://127.0.0.1:5000')  # Change the address if your server is running on a different host or port

    try:
        formatted_time = datetime.now().strftime("%H:%M:%S")

        start_lat, start_lon = 46.221461, -124.107230
        distance_per_step = 2.0  # Move 0.5 miles per step
        forward_bearing = 45  # Bearing for moving forward
        zigzag_bearing = 135  # Initial bearing for zigzagging

        for step in range(500):
            if step % 2 == 0:
                # Even steps move forward
                bearing = forward_bearing
            else:
                # Odd steps zigzag
                bearing = zigzag_bearing

            start_lat, start_lon = calculate_new_coordinates(start_lat, start_lon, distance_per_step, bearing)

            callsign = 'AE7BQ-1'
            test_data = {'lat': start_lat, 'lon': start_lon, 'callsign': callsign, 'raw_packet': callsign, 'formatted_time': formatted_time}

            sio.emit('update_map', test_data)
            print(f"Test data sent to the server: {test_data}")
            time.sleep(0.3)  # Send test data every 10 seconds

    except KeyboardInterrupt:
        sio.disconnect()
        print("Disconnected from server")
